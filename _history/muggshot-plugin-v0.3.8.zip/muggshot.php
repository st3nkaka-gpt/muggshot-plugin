<?php
/*
Plugin Name: Muggshot
Description: Mock Instagram plugin
Version: 0.3.8
*/
