<?php
/*
Plugin Name: Muggshot
Description: Visar Instagram-inlägg baserade på hashtags. Grid-layout, betygssystem, dummyinlägg och shortcode-sida.
Version: 0.4.8
Author: Thomas & Effie
*/

defined('ABSPATH') or die('No script kiddies please!');

// Aktivera post-thumbnails
add_theme_support('post-thumbnails');

// CPT
function muggshot_register_post_type() {
    register_post_type('muggshot_post', array(
        'labels' => array(
            'name' => __('Muggshot-inlägg'),
            'singular_name' => __('Muggshot-inlägg'),
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-format-gallery',
        'show_in_rest' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
    ));
}
add_action('init', 'muggshot_register_post_type');

// Skapa dummyinlägg
function muggshot_create_dummy_posts() {
    $existing = get_posts(array('post_type' => 'muggshot_post'));
    if (count($existing) > 0) return;

    for ($i = 1; $i <= 20; $i++) {
        $post_id = wp_insert_post(array(
            'post_title' => "Dummyinlägg #{$i}",
            'post_type' => 'muggshot_post',
            'post_status' => 'publish',
        ));
        $img_path = plugin_dir_path(__FILE__) . "assets/images/mock_img_{$i}.png";
        if (file_exists($img_path)) {
            $upload_dir = wp_upload_dir();
            $filename = basename($img_path);
            $new_path = $upload_dir['path'] . '/' . $filename;
            copy($img_path, $new_path);
            $wp_filetype = wp_check_filetype($filename, null);
            $attachment = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title' => sanitize_file_name($filename),
                'post_content' => '',
                'post_status' => 'inherit'
            );
            $attach_id = wp_insert_attachment($attachment, $new_path, $post_id);
            require_once(ABSPATH . 'wp-admin/includes/image.php');
            $attach_data = wp_generate_attachment_metadata($attach_id, $new_path);
            wp_update_attachment_metadata($attach_id, $attach_data);
            set_post_thumbnail($post_id, $attach_id);
        }
    }
}
register_activation_hook(__FILE__, 'muggshot_create_dummy_posts');

// Skapa sida med shortcode
function muggshot_create_page() {
    $slug = 'muggshot-demo';
    $existing = get_page_by_path($slug);
    if (!$existing) {
        wp_insert_post(array(
            'post_title' => 'Muggshot Demo',
            'post_name' => $slug,
            'post_content' => '[muggshot-lista antal="20" visa_caption="ja" visa_datum="ja" visa_hashtags="ja" kolumner="4"]',
            'post_status' => 'publish',
            'post_type' => 'page',
        ));
    }
}
register_activation_hook(__FILE__, 'muggshot_create_page');

// Shortcode
function muggshot_render_list($atts) {
    $atts = shortcode_atts(array(
        'antal' => 10,
        'visa_caption' => 'nej',
        'visa_datum' => 'nej',
        'visa_hashtags' => 'nej',
        'kolumner' => 3
    ), $atts, 'muggshot-lista');

    $args = array(
        'post_type' => 'muggshot_post',
        'posts_per_page' => $atts['antal']
    );
    $query = new WP_Query($args);
    if (!$query->have_posts()) return '<p>Inga inlägg hittades.</p>';

    ob_start();
    echo "<div class='muggshot-grid kol-{$atts['kolumner']}'>";
    while ($query->have_posts()) : $query->the_post();
        $image_url = get_the_post_thumbnail_url(get_the_ID(), 'medium');
        echo "<div class='muggshot-item'>";
        if ($image_url) echo "<img src='{$image_url}' alt=''>";
        if ($atts['visa_caption'] === 'ja') echo "<div class='caption'>" . get_the_title() . "</div>";
        if ($atts['visa_datum'] === 'ja') echo "<div class='datum'>" . get_the_date() . "</div>";
        if ($atts['visa_hashtags'] === 'ja') echo "<div class='hashtags'>#" . implode(' #', wp_get_post_tags(get_the_ID(), array('fields' => 'names'))) . "</div>";
        echo "<div class='stars'>⭐️⭐️⭐️⭐️</div>";
        echo "</div>";
    endwhile;
    echo "</div>";
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('muggshot-lista', 'muggshot_render_list');

// Admin meny
function muggshot_admin_menu() {
    add_menu_page('Muggshot', 'Muggshot', 'manage_options', 'muggshot', 'muggshot_admin_page', 'dashicons-camera');
}
add_action('admin_menu', 'muggshot_admin_menu');

function muggshot_admin_page() {
    echo "<div class='wrap'><h1>Muggshot Plugin</h1><p>Pluginet är installerat. Dummyinlägg är publicerade. Testa sidan: <a href='/muggshot-demo' target='_blank'>Muggshot Demo</a></p></div>";
}
?>
