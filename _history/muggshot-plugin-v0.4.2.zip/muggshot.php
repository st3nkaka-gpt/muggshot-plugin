<?php
/*
Plugin Name: Muggshot
Description: Visar mockade Instagram-inlägg med valbara attribut, rösträkning, och filtrering
Version: 0.4.2
*/

add_action('init', 'muggshot_register_post_type');
function muggshot_register_post_type() {
    register_post_type('muggshot_post', array(
        'labels' => array('name' => 'Muggshot-inlägg', 'singular_name' => 'Muggshot-inlägg'),
        'public' => true, 'has_archive' => true, 'show_in_rest' => true,
        'menu_position' => 20, 'menu_icon' => 'dashicons-format-gallery',
        'supports' => array('title', 'editor', 'thumbnail'),
    ));
}

add_shortcode('muggshot-lista', 'muggshot_render_list');
function muggshot_render_list($atts) {
    $atts = shortcode_atts(array(
        'antal' => 10,
        'visa_caption' => 'ja',
        'visa_hashtags' => 'ja',
        'visa_datum' => 'ja',
        'filter' => ''
    ), $atts, 'muggshot-lista');

    $antal = min(intval($atts['antal']), 20);
    $filter = strtolower($atts['filter']);
    $output = '<style>
    .muggshot-grid { display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; }
    .muggshot-card { width: 280px; background: #fff; border: 1px solid #ccc; box-shadow: 0 1px 4px rgba(0,0,0,0.1); }
    .muggshot-card img { width: 100%; height: auto; display: block; }
    .muggshot-content { padding: 10px; font-family: sans-serif; }
    .muggshot-caption { font-weight: bold; margin-bottom: 4px; }
    .muggshot-meta { font-size: 0.85em; color: #555; }
    .muggshot-stars { margin-top: 8px; }
    .muggshot-stars span {
        font-size: 1.2em; color: #ccc; cursor: pointer;
        transition: color 0.2s;
    }
    .muggshot-stars span.active { color: #f39c12; }
    </style>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const allStars = document.querySelectorAll(".muggshot-stars span");
        allStars.forEach(star => {
            star.addEventListener("mouseover", function() {
                const value = parseInt(this.dataset.value);
                const parent = this.parentElement;
                Array.from(parent.children).forEach(s => {
                    s.classList.remove("active");
                    if (parseInt(s.dataset.value) <= value) s.classList.add("active");
                });
            });
        });
    });
    </script>';

    $output .= '<div class="muggshot-grid">';
    for ($i = 1; $i <= $antal; $i++) {
        $img_url = plugin_dir_url(__FILE__) . 'assets/images/mock_img_' . $i . '.png';
        $caption = 'Testbild ' . $i;
        $hashtags = '#muggshot #mockdata #bild' . $i;
        $datum = date('Y-m-d', strtotime('2025-07-' . (10+$i)));

        if ($filter && strpos(strtolower($hashtags), $filter) === false) continue;

        $output .= '<div class="muggshot-card">';
        $output .= '<img src="' . esc_url($img_url) . '" alt="' . esc_attr($caption) . '">';
        $output .= '<div class="muggshot-content">';
        if ($atts['visa_caption'] === 'ja') $output .= '<div class="muggshot-caption">' . esc_html($caption) . '</div>';
        if ($atts['visa_hashtags'] === 'ja') $output .= '<div class="muggshot-meta">' . esc_html($hashtags) . '</div>';
        if ($atts['visa_datum'] === 'ja') $output .= '<div class="muggshot-meta">' . esc_html($datum) . '</div>';

        $output .= '<div class="muggshot-stars">';
        for ($j = 1; $j <= 4; $j++) {
            $output .= '<span data-value="'.$j.'">&#9733;</span>';
        }
        $output .= '</div></div></div>';
    }
    $output .= '</div>';
    return $output;
}
