<?php
/*
Plugin Name: Muggshot
Description: Visar mockade Instagram-inlägg med bilder, captions och hashtags
Version: 0.4.0
*/

add_shortcode('muggshot-lista', 'muggshot_render_list');

function muggshot_render_list($atts) {
    $output = '<div class="muggshot-grid" style="display: flex; flex-wrap: wrap; gap: 20px;">';
    for ($i = 1; $i <= 6; $i++) {
        $img_url = plugin_dir_url(__FILE__) . 'assets/images/mock_img_' . $i . '.png';
        $caption = 'Detta är en testbild nummer ' . $i;
        $hashtags = '#muggshot #mockdata #bild' . $i;
        $datum = date('Y-m-d', strtotime('2025-07-' . (18+$i)));
        $output .= '<div style="flex: 1 1 30%; min-width: 250px; background: #f9f9f9; padding: 10px; border-radius: 8px;">';
        $output .= '<img src="' . esc_url($img_url) . '" style="width: 100%; height: auto; border-radius: 4px;">';
        $output .= '<p style="margin: 8px 0 4px; font-weight: bold;">' . esc_html($caption) . '</p>';
        $output .= '<p style="margin: 0; font-size: 0.9em; color: #666;">' . esc_html($hashtags) . '</p>';
        $output .= '<p style="margin: 0; font-size: 0.8em; color: #aaa;">' . esc_html($datum) . '</p>';
        $output .= '</div>';
    }
    $output .= '</div>';
    return $output;
}
