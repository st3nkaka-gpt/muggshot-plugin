<?php
/*
Plugin Name: Muggshot
Plugin URI: https://muggshot.se
Description: Visar Instagram-inlägg baserade på hashtags. Responsiv layout, betygssystem, och shortcode-generator.
Version: 0.4.6
Author: Thomas & Effie
*/

defined('ABSPATH') or die('No script kiddies please!');

// Registrera custom post type
function muggshot_register_post_type() {
    register_post_type('muggshot_post', array(
        'labels' => array(
            'name' => __('Muggshot-inlägg'),
            'singular_name' => __('Muggshot-inlägg'),
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-format-gallery',
        'show_in_rest' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
    ));
}
add_action('init', 'muggshot_register_post_type');

// Registrera shortcode
function muggshot_render_list($atts) {
    return "<div class='muggshot-lista-wrapper'>[Inlägg laddas här i v0.4.6]</div>";
}
add_shortcode('muggshot-lista', 'muggshot_render_list');

// Lägg till menyval
function muggshot_admin_menu() {
    add_menu_page('Muggshot', 'Muggshot', 'manage_options', 'muggshot', 'muggshot_admin_page', 'dashicons-camera');
}
add_action('admin_menu', 'muggshot_admin_menu');

function muggshot_admin_page() {
    echo "<div class='wrap'><h1>Muggshot Plugin</h1><p>Shortcode-generator och inställningar kommer här.</p></div>";
}
?>
