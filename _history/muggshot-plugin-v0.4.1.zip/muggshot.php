<?php
/*
Plugin Name: Muggshot
Description: Visar mockade Instagram-inlägg med bilder, captions, hashtags, stjärnbetyg och CPT
Version: 0.4.1
*/

add_action('init', 'muggshot_register_post_type');
function muggshot_register_post_type() {
    register_post_type('muggshot_post', array(
        'labels' => array(
            'name' => 'Muggshot-inlägg',
            'singular_name' => 'Muggshot-inlägg'
        ),
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-format-gallery',
        'supports' => array('title', 'editor', 'thumbnail'),
    ));
}

add_shortcode('muggshot-lista', 'muggshot_render_list');
function muggshot_render_list($atts) {
    $output = '<style>
    .muggshot-grid { display: flex; flex-wrap: wrap; gap: 20px; justify-content: center; }
    .muggshot-card { width: 280px; background: #fff; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);}
    .muggshot-card img { width: 100%; height: auto; display: block; }
    .muggshot-content { padding: 10px; }
    .muggshot-caption { font-weight: bold; margin-bottom: 4px; }
    .muggshot-meta { font-size: 0.85em; color: #666; }
    .muggshot-stars { margin-top: 8px; color: #ccc; cursor: pointer; }
    .muggshot-stars span:hover,
    .muggshot-stars span:hover ~ span { color: #f39c12; }
    </style>';

    $output .= '<div class="muggshot-grid">';
    for ($i = 1; $i <= 6; $i++) {
        $img_url = plugin_dir_url(__FILE__) . 'assets/images/mock_img_' . $i . '.png';
        $caption = 'Testbild ' . $i;
        $hashtags = '#muggshot #mockdata #bild' . $i;
        $datum = date('Y-m-d', strtotime('2025-07-' . (18+$i)));

        $output .= '<div class="muggshot-card">';
        $output .= '<img src="' . esc_url($img_url) . '" alt="' . esc_attr($caption) . '">';
        $output .= '<div class="muggshot-content">';
        $output .= '<div class="muggshot-caption">' . esc_html($caption) . '</div>';
        $output .= '<div class="muggshot-meta">' . esc_html($hashtags) . '</div>';
        $output .= '<div class="muggshot-meta">' . esc_html($datum) . '</div>';
        $output .= '<div class="muggshot-stars">';
        $output .= '<span>★</span><span>★</span><span>★</span><span>★</span>';
        $output .= '</div>';
        $output .= '</div></div>';
    }
    $output .= '</div>';
    return $output;
}
