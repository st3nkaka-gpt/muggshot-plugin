<?php
/*
Plugin Name: Muggshot
Description: Visar Instagram-inlägg i grid med bilder, hashtags, datum och captions. Responsiv layout med shortcode och röstning.
Version: 0.4.12
Author: Thomas & Effie
*/

defined('ABSPATH') or die('No script kiddies please!');

// Post thumbnails
add_theme_support('post-thumbnails');

// CPT
function muggshot_register_post_type() {
    register_post_type('muggshot_post', array(
        'labels' => array(
            'name' => __('Muggshot-inlägg'),
            'singular_name' => __('Muggshot-inlägg'),
        ),
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-format-gallery',
        'show_in_rest' => true,
        'supports' => array('title', 'editor', 'thumbnail', 'custom-fields'),
    ));
}
add_action('init', 'muggshot_register_post_type');

// Ladda CSS och JS
function muggshot_enqueue_assets() {
    wp_enqueue_style('muggshot-style', plugin_dir_url(__FILE__) . 'assets/css/muggshot.css');
    wp_enqueue_script('muggshot-rating', plugin_dir_url(__FILE__) . 'assets/js/ratings.js', array(), null, true);
}
add_action('wp_enqueue_scripts', 'muggshot_enqueue_assets');

// Shortcode
function muggshot_render_list($atts) {
    $atts = shortcode_atts(array(
        'antal' => 10,
        'visa_caption' => 'nej',
        'visa_datum' => 'nej',
        'visa_hashtags' => 'nej',
        'kolumner' => 3
    ), $atts, 'muggshot-lista');

    $args = array(
        'post_type' => 'muggshot_post',
        'posts_per_page' => $atts['antal']
    );
    $query = new WP_Query($args);
    if (!$query->have_posts()) return '<p>Inga inlägg hittades.</p>';

    ob_start();
    echo "<div class='muggshot-grid kol-{$atts['kolumner']}'>";
    while ($query->have_posts()) : $query->the_post();
        $post_id = get_the_ID();
        $image_url = get_the_post_thumbnail_url($post_id, 'medium');
        echo "<div class='muggshot-item'>";
        if ($image_url) echo "<img src='{$image_url}' alt=''>";
        echo "<div class='muggshot-item-content'>";
        if ($atts['visa_caption'] === 'ja') echo "<div class='caption'>" . get_the_title() . "</div>";
        if ($atts['visa_datum'] === 'ja') echo "<div class='datum'>" . get_the_date() . "</div>";
        if ($atts['visa_hashtags'] === 'ja') {
            $tags = wp_get_post_tags($post_id, array('fields' => 'names'));
            echo "<div class='hashtags'>#" . implode(' #', $tags) . "</div>";
        }
        echo "<div class='stars' data-post-id='{$post_id}'>";
        for ($i = 0; $i < 4; $i++) echo "<span class='star'>★</span>";
        echo "</div>";
        echo "</div></div>";
    endwhile;
    echo "</div>";
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('muggshot-lista', 'muggshot_render_list');

// Admin meny
function muggshot_admin_menu() {
    add_menu_page('Muggshot', 'Muggshot', 'manage_options', 'muggshot', 'muggshot_admin_page', 'dashicons-camera');
}
add_action('admin_menu', 'muggshot_admin_menu');

function muggshot_admin_page() {
    echo "<div class='wrap'><h1>Muggshot Plugin</h1><p>Pluginet är installerat. Använd <code>[muggshot-lista]</code> för att visa inlägg.</p></div>";
}
?>
