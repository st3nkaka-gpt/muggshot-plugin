<?php
/*
Plugin Name: Muggshot
Description: Visar mockade Instagram-inlägg med rösträkning, gridfix och adminfix
Version: 0.4.3
*/

add_action('init', 'muggshot_register_post_type');
function muggshot_register_post_type() {
    register_post_type('muggshot_post', array(
        'labels' => array(
            'name' => 'Muggshot-inlägg',
            'singular_name' => 'Muggshot-inlägg',
            'add_new_item' => 'Lägg till nytt inlägg',
            'edit_item' => 'Redigera Muggshot-inlägg',
            'new_item' => 'Nytt Muggshot-inlägg',
            'view_item' => 'Visa Muggshot-inlägg',
            'search_items' => 'Sök Muggshot-inlägg',
            'not_found' => 'Inga inlägg hittades',
            'not_found_in_trash' => 'Inga inlägg i papperskorgen'
        ),
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-format-gallery',
        'supports' => array('title', 'editor', 'thumbnail'),
    ));
}

add_shortcode('muggshot-lista', 'muggshot_render_list');
function muggshot_render_list($atts) {
    $atts = shortcode_atts(array(
        'antal' => 10,
        'visa_caption' => 'ja',
        'visa_hashtags' => 'ja',
        'visa_datum' => 'ja',
        'filter' => ''
    ), $atts, 'muggshot-lista');

    $antal = min(intval($atts['antal']), 20);
    $filter = strtolower($atts['filter']);
    $output = '<style>
    .muggshot-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; }
    .muggshot-card { background: #fff; border: 1px solid #ccc; box-shadow: 0 1px 4px rgba(0,0,0,0.1); }
    .muggshot-card img { width: 100%; height: auto; display: block; }
    .muggshot-content { padding: 10px; font-family: sans-serif; }
    .muggshot-caption { font-weight: bold; margin-bottom: 4px; }
    .muggshot-meta { font-size: 0.85em; color: #555; }
    .muggshot-stars span {
        font-size: 1.2em; color: #ccc; cursor: pointer; transition: color 0.2s;
    }
    .muggshot-stars span.active { color: #f39c12; }
    </style>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll(".muggshot-stars").forEach(container => {
            const id = container.dataset.id;
            const stars = container.querySelectorAll("span");
            let saved = localStorage.getItem("vote_" + id);
            if (saved) {
                stars.forEach((s, idx) => {
                    if (idx < saved) s.classList.add("active");
                });
            }
            stars.forEach((star, idx) => {
                star.addEventListener("click", () => {
                    localStorage.setItem("vote_" + id, idx + 1);
                    stars.forEach((s, j) => {
                        s.classList.toggle("active", j <= idx);
                    });
                });
            });
        });
    });
    </script>';

    $output .= '<div class="muggshot-grid">';
    for ($i = 1; $i <= $antal; $i++) {
        $img_url = plugin_dir_url(__FILE__) . 'assets/images/mock_img_' . $i . '.png';
        $caption = 'Testbild ' . $i;
        $hashtags = '#muggshot #mockdata #bild' . $i;
        $datum = date('Y-m-d', strtotime('2025-07-' . (10+$i)));

        if ($filter && strpos(strtolower($hashtags), $filter) === false) continue;

        $output .= '<div class="muggshot-card">';
        $output .= '<img src="' . esc_url($img_url) . '" alt="' . esc_attr($caption) . '">';
        $output .= '<div class="muggshot-content">';
        if ($atts['visa_caption'] === 'ja') $output .= '<div class="muggshot-caption">' . esc_html($caption) . '</div>';
        if ($atts['visa_hashtags'] === 'ja') $output .= '<div class="muggshot-meta">' . esc_html($hashtags) . '</div>';
        if ($atts['visa_datum'] === 'ja') $output .= '<div class="muggshot-meta">' . esc_html($datum) . '</div>';

        $output .= '<div class="muggshot-stars" data-id="mock_' . $i . '">';
        for ($j = 1; $j <= 4; $j++) {
            $output .= '<span data-value="'.$j.'">&#9733;</span>';
        }
        $output .= '</div></div></div>';
    }
    $output .= '</div>';
    return $output;
}
