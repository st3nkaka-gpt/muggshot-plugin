<?php
/*
Plugin Name: Muggshot
Description: Hämtar inlägg från Instagram (mock) och skapar WP-poster automatiskt.
Version: 0.3
Author: Thomas Palmqvist
*/

defined('ABSPATH') or die('No script kiddies please!');

require_once plugin_dir_path(__FILE__) . 'includes/fetch_mock.php';
?>
