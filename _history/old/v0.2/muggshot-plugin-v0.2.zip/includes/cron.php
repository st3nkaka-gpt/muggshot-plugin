<?php
function muggshot_fetch_mock() {
    // Här skulle inlägg hämtas från API
    // Detta är en mockad placeholder
}
if (!wp_next_scheduled('muggshot_fetch_event')) {
    wp_schedule_event(time(), 'hourly', 'muggshot_fetch_event');
}
add_action('muggshot_fetch_event', 'muggshot_fetch_mock');
?>
