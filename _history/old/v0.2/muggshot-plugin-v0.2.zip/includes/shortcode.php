<?php
function muggshot_shortcode($atts) {
    $atts = shortcode_atts(['antal' => 5], $atts);
    $query = new WP_Query([
        'post_type' => 'instapost',
        'posts_per_page' => intval($atts['antal'])
    ]);

    ob_start();
    echo '<div class="muggshot-grid">';
    while ($query->have_posts()) {
        $query->the_post();
        echo '<div class="muggshot-item">';
        the_post_thumbnail('medium');
        echo '<h3>' . get_the_title() . '</h3>';
        echo '</div>';
    }
    echo '</div>';
    wp_reset_postdata();
    return ob_get_clean();
}
add_shortcode('muggshot-lista', 'muggshot_shortcode');
?>
