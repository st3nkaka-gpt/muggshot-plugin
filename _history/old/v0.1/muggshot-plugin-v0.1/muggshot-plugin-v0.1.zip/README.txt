Muggshot Pluginstruktur - v0.1
------------------------------
Skapat: 2025-07-20

Mappar:
- admin/        : Backend-gränssnitt och formulär
- includes/     : Funktioner, API-anrop, logik
- templates/    : Frontend-rendering för shortcodes
- assets/css/   : Stilark (separata per vy)
- assets/js/    : Framtida JS (t.ex. röstning, scroll, modaler)
- languages/    : Förberett för översättning

WCAG 2.2 & GDPR redo.
