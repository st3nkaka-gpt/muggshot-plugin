<?php
/*
Plugin Name: Muggshot
Description: Visa, filtrera och rösta på Instagram-inlägg baserade på hashtags från publika konton. Anpassat för WCAG 2.2 och GDPR.
Version: 0.1
Author: Thomas Palmqvist
*/

defined('ABSPATH') or die('No script kiddies please!');

require_once plugin_dir_path(__FILE__) . 'includes/init.php';
?>
