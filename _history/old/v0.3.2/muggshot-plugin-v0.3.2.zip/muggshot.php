<?php
/*
Plugin Name: Muggshot
Description: Instagram hashtag viewer med mockhämtning, röstning, WCAG-stöd och GDPR.
Version: 0.3.2
Author: Thomas Palmqvist
*/

defined('ABSPATH') or die('No script kiddies please!');

require_once plugin_dir_path(__FILE__) . 'includes/init.php';
require_once plugin_dir_path(__FILE__) . 'includes/custom_post_types.php';
require_once plugin_dir_path(__FILE__) . 'includes/shortcode.php';
require_once plugin_dir_path(__FILE__) . 'includes/fetch_mock.php';
?>
