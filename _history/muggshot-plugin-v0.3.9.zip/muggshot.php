<?php
/*
Plugin Name: Muggshot
Description: Visar mockade Instagram-inlägg
Version: 0.3.9
*/

add_shortcode('muggshot-lista', 'muggshot_render_list');

function muggshot_render_list($atts) {
    $output = '<div class="muggshot-grid" style="display: flex; flex-wrap: wrap; gap: 10px;">';
    for ($i = 1; $i <= 6; $i++) {
        $img_url = plugin_dir_url(__FILE__) . 'assets/images/mock_img_' . $i . '.png';
        $output .= '<div style="flex: 1 1 30%; min-width: 200px;"><img src="' . esc_url($img_url) . '" style="max-width: 100%; height: auto;"><p>Mock-inlägg #' . $i . '</p></div>';
    }
    $output .= '</div>';
    return $output;
}
